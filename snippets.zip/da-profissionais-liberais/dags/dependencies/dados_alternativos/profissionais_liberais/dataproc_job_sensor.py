# -*- coding: utf-8 -*-
# !/usr/bin/env python3
# ================================================================================================
# Module: dag_utils.py
# Author: Fernando Theodoro Guimarães
# E-mail: fernando.guimaraes@boavistascpc.com.br
# Description: This module is responsible for supporting the construction of the DAG
# Value Stream: Data
# Squad: Dados Alternativos
# ================================================================================================
from airflow.exceptions import AirflowSkipException
from airflow.models import BaseOperator
from google.cloud import dataproc_v1 as dataproc
from dependencies.dados_alternativos.profissionais_liberais.variables import Variables


class DataprocJobSensor(BaseOperator):
    def __init__(self, pipeline_config, *args, **kwargs):
        self.pipeline_config = pipeline_config
        self.variables = Variables(self.pipeline_config)
        super().__init__(*args, **kwargs)

    def instantiate_client(self):
        return dataproc.ClusterControllerClient()

    def get_request(self):
        return dataproc.GetClusterRequest(
            project_id=self.variables.get_project_id,
            region=self.variables.get_region,
            cluster_name=self.variables.get_cluster_id,
        )

    def get_response_status(self):
        client = self.instantiate_client()
        request = self.get_request()
        response = client.get_cluster(request=request)
        return response.status.state.name

    def execute(self, context):
        status = self.get_response_status()
        if status != "RUNNING":
            return True
        return False
