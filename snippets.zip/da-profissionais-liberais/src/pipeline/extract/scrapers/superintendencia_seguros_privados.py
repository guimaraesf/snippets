# -*- coding: utf-8 -*-
# !/usr/bin/env python3
# ================================================================================================
# Module: superintendencia_seguro_privado.py
# Author: Fernando Theodoro Guimarães
# E-mail: fernando.guimaraes@boavistascpc.com.br
# Description: This module is responsible for scraping data from the Superintendência Seguro Privado
# Value Stream: Data
# Squad: Dados Alternativos
# ================================================================================================
import asyncio
import ssl
import sys

import aiohttp
import nest_asyncio
from aiohttp import TCPConnector
from async_requests import AsyncRequest
from file_handler import PandasFileHandle
from gcs_client import GcsClient
from gcs_manager import GcsManager
from google.cloud import storage
from interface_strategy import Strategy
from logger import Logger
from ssl_context import SslContextConfigurator
from stopwatch import Stopwatch
from variables import Variables

# pylint: disable=too-many-try-statements


class ScraperSusep(Strategy):
    """
    Class responsible for scraping concrete Susep data.
    """

    def __init__(
        self,
        url: str,
        bucket: storage.Bucket,
        logger=Logger,
        gcs_manager=GcsManager,
        pandas_file_handle=PandasFileHandle,
        async_request=AsyncRequest,
        variables=Variables
    ) -> None:
        """
        Initializes the ConcreteScraperSusep class.

        Args:
            url (str): URL of the website to be scraped.
            logger (logging.Logger): The logger to be used for logging.
            pandas_file_handle (PandasFileHandle, optional): Handler to handle CSV operations. Defaults to PandasFileHandle.
            async_request (AsyncRequest, optional): Asynchronous request to make network calls. Defaults to AsyncRequest.
            utils (Utils, optional): A utility class that provides various helper methods. Defaults to Utils.
        """
        self.url = url
        self.bucket = bucket
        self.logger = logger()
        self.gcs_manager = gcs_manager(self.bucket, self.logger)
        self.async_request = async_request
        self.pandas_file_handle = pandas_file_handle(self.logger)
        self.variables = variables
        self.total_records = None
        self.take = 10

    def create_blob_staging_path(self, page: int) -> str:
        """
        Create a blob path for a specific file in Google Cloud Storage.

        Returns:
            str: The blob path in Google Cloud Storage.
        """
        layer_name = "staging"
        dir_name = self.variables.DIR_NAME_SUSEP
        file_name = self.variables.FILENAME.format(f"susep_{str(page).zfill(4)}")
        blob_name = self.variables.BLOB_NAME.format(layer_name, dir_name, file_name)
        return blob_name

    def process_df_from_json(self, data: dict, blob_name: str) -> None:
        """
        Processes a DataFrame from a JSON object and saves it to a CSV file.

        Args:
            data (dict): The data to be processed.
            blob_name (str): The path where the file will be saved in bucket.
        """
        self.logger.info("Reading as DataFrame from JSON response.")
        df = self.pandas_file_handle.normalize_json_file(data)
        csv_data = self.pandas_file_handle.convert_to_csv_file(df=df)

        self.logger.info("Uploading CSV files in the bucket.")
        blob = self.gcs_manager.create_blob(blob_name)
        self.gcs_manager.blob_upload_from_string(blob, csv_data)

        if self.gcs_manager.check_if_blob_exists(blob):
            self.logger.info(f"File were uploaded successfully to GCS: {blob.name}")

    async def process_response(self, session: aiohttp.ClientSession, page: int) -> int:
        """
        Processes the response for a given session and page.

        Args:
            session (aiohttp.ClientSession): The session to process the response for.
            page (str): The page to process the response for.

        Returns:
            int: Return the total_records.
        """
        url = self.url.format(page)
        request = self.async_request(session, url, self.logger)
        json_response = await request.fetch_json_response()
        results = json_response.get("retorno")
        total_records = results.get("totalRegistros")
        data = results.get("registros")
        blob_name = self.create_blob_staging_path(page)
        self.process_df_from_json(data, blob_name)
        await asyncio.sleep(5)
        return total_records

    def processed_until_last_page(self, page: int, total_records_list: tuple) -> bool:
        """
        Checks if all pages have been processed.

        Args:
            page (int): The current page number.
            total_records_list (tuple): A tuple containing the total number of records on each page.

        Returns:
            bool: Returns True if all pages have been processed, False otherwise.
        """
        total_records = max(total_records_list)
        if not total_records_list:
            return False
        if page - 1 >= total_records:
            return False
        return None

    async def scraper(self, connector: TCPConnector) -> None:
        """
        Main method that runs all tasks for all states.
        """
        async with aiohttp.ClientSession(connector=connector, headers=self.variables.HEADERS) as session:
            page = 1
            while True:
                tasks = [self.process_response(session, i) for i in range(page, page + self.take)]
                total_records_list = await asyncio.gather(*tasks)
                if self.processed_until_last_page(page, total_records_list):
                    self.logger.info("Finished scraping for Susep.")
                    break
                page += self.take


if __name__ == "__main__":
    logger = Logger()

    stopwatch = Stopwatch(logger)
    stopwatch.start()

    nest_asyncio.apply()

    BUCKET_ID = sys.argv[2]
    PROJECT_ID = sys.argv[4]

    gcs_client = GcsClient(PROJECT_ID, BUCKET_ID, logger)
    client = gcs_client.instantiate_client()
    bucket = gcs_client.create_bucket_obj(client)

    ssl_context_configurator = SslContextConfigurator(logger)
    ssl_context = ssl_context_configurator.create_context(True, ssl.CERT_REQUIRED)
    connector = TCPConnector(ssl=ssl_context)

    scraper_susep = ScraperSusep(Variables.URL_SUSEP, bucket)
    asyncio.run(scraper_susep.scraper(connector))

    stopwatch.stop()
    stopwatch.show_elapsed_time()
