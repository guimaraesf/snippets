# -*- coding: utf-8 -*-
#!/usr/bin/env python3
# ================================================================================================
# Module: validator.py
# Author: Fernando Theodoro Guimarães
# E-mail: fernando.guimaraes@boavistascpc.com.br
# Description:
# Value Stream: Data
# Squad: Dados Alternativos
# ================================================================================================
