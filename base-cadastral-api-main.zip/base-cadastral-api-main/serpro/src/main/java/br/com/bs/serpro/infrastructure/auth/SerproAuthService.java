package br.com.bs.serpro.infrastructure.auth;

public interface SerproAuthService {

    String getToken();

}
