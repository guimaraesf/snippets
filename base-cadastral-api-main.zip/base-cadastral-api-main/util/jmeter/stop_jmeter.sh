export JMETER_HOME=/home/tr_ehuerta/jmeter/apache-jmeter-5.0
export JMETER_DOCS=/home/tr_ehuerta/jmeter

${JMETER_HOME}/bin/shutdown.sh